/*
 * Crafting Dead
 * Copyright (C) 2022  NexusNode LTD
 *
 * This Non-Commercial Software License Agreement (the "Agreement") is made between
 * you (the "Licensee") and NEXUSNODE (BRAD HUNTER). (the "Licensor").
 * By installing or otherwise using Crafting Dead (the "Software"), you agree to be
 * bound by the terms and conditions of this Agreement as may be revised from time
 * to time at Licensor's sole discretion.
 *
 * If you do not agree to the terms and conditions of this Agreement do not download,
 * copy, reproduce or otherwise use any of the source code available online at any time.
 *
 * https://github.com/nexusnode/crafting-dead/blob/1.18.x/LICENSE.txt
 *
 * https://craftingdead.net/terms.php
 */

package com.craftingdead.core.client;

import com.craftingdead.core.client.crosshair.CrosshairManager;
import com.craftingdead.core.client.tutorial.ModTutorialSteps;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.neoforged.neoforge.common.ModConfigSpec;

public class ClientConfig {

  public final ModConfigSpec.BooleanValue displayBlood;

  public final ModConfigSpec.ConfigValue<String> killSound;

  public final ModConfigSpec.ConfigValue<String> crosshair;

  public final ModConfigSpec.EnumValue<ModTutorialSteps> tutorialStep;

  public ClientConfig(ModConfigSpec.Builder builder) {
    builder.push("client");
    {
      this.displayBlood = builder
          .translation("options.craftingdead.client.display_blood")
          .comment("Display the red screen flash when the local player takes damage")
          .define("displayBlood", true);
      this.killSound = builder
          .translation("options.craftingdead.client.kill_sound")
          .define("killSound", SoundEvents.TRIDENT_RETURN.getLocation().toString(),
              v -> v instanceof String && ResourceLocation.tryParse((String) v) != null);
      this.tutorialStep = builder
          .comment("Internal")
          .defineEnum("tutorialStep", ModTutorialSteps.OPEN_EQUIPMENT_MENU);
      this.crosshair = builder
          .translation("options.craftingdead.client.crosshair")
          .define("crosshair", CrosshairManager.DEFAULT_CROSSHAIR.toString(),
              o -> o instanceof String s && ResourceLocation.tryParse(s) != null);
    }
    builder.pop();
  }
}
