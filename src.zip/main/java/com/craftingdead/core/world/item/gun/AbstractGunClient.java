/*
 * Crafting Dead
 * Copyright (C) 2022  NexusNode LTD
 *
 * This Non-Commercial Software License Agreement (the "Agreement") is made between
 * you (the "Licensee") and NEXUSNODE (BRAD HUNTER). (the "Licensor").
 * By installing or otherwise using Crafting Dead (the "Software"), you agree to be
 * bound by the terms and conditions of this Agreement as may be revised from time
 * to time at Licensor's sole discretion.
 *
 * If you do not agree to the terms and conditions of this Agreement do not download,
 * copy, reproduce or otherwise use any of the source code available online at any time.
 *
 * https://github.com/nexusnode/crafting-dead/blob/1.18.x/LICENSE.txt
 *
 * https://craftingdead.net/terms.php
 */

package com.craftingdead.core.world.item.gun;

import com.craftingdead.core.client.util.ClientFrameTimeUtil;
import com.craftingdead.core.util.RegistryNameUtil;
import com.craftingdead.core.ServerConfig;
import com.craftingdead.core.world.item.gun.attachment.Attachments;
import java.util.HashMap;
import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import java.util.Optional;
import org.jetbrains.annotations.Nullable;
import com.craftingdead.core.CraftingDead;
import com.craftingdead.core.client.ClientDist;
import com.craftingdead.core.client.animation.Animation;
import com.craftingdead.core.client.animation.AnimationController;
import com.craftingdead.core.network.NetworkChannel;
import com.craftingdead.core.network.message.play.ValidatePendingHitMessage;
import com.craftingdead.core.sounds.ModSoundEvents;
import com.craftingdead.core.world.entity.extension.LivingExtension;
import com.craftingdead.core.world.item.gun.attachment.Attachment;
import com.google.common.collect.Multimap;
import com.google.common.collect.Multimaps;
import it.unimi.dsi.fastutil.ints.Int2ObjectLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.Util;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public abstract class AbstractGunClient<T extends AbstractGun>
    implements GunClient, GunClientRuntime {

  private static final Logger LOGGER = LogUtils.getLogger();

  private static final int MUZZLE_FLASH_DURATION_TICKS = 2;

  protected final ClientDist client = CraftingDead.getInstance().getClientDist();

  protected final Minecraft minecraft = Minecraft.getInstance();

  protected final T gun;

  private final AnimationController animationController = new AnimationController();

  private int lastShotCount;

  private int remainingFlashTicks;

  private long secondaryActionSoundStartTimeMs;

  @Nullable
  private Animation reloadAnimation;

  private static final Multimap<Integer, PendingHit> LIVING_HIT_VALIDATION_BUFFER =
      Multimaps.synchronizedListMultimap(
          Multimaps.newListMultimap(new Int2ObjectLinkedOpenHashMap<>(), ObjectArrayList::new));

  private static byte hitValidationTicks = 0;

  @Nullable
  private Animation currentShootAnimation;

  public AbstractGunClient(T gun) {
    this.gun = gun;
  }

  @Override
  public void execute(Runnable task) {
    this.minecraft.execute(task);
  }

  @Override
  public void startReload(boolean removingMagazine) {
    this.reloadAnimation = this.getAnimation(GunAnimationEvent.RELOAD);
    if (this.reloadAnimation instanceof
        com.craftingdead.core.client.animation.gun.ReloadAnimation reloadAnimation) {
      reloadAnimation.setRemovingMagazine(removingMagazine);
    }
    this.animationController.addAnimation(this.reloadAnimation);
  }

  @Override
  public void cancelReload() {
    this.gun.getReloadSound().ifPresent(sound -> this.minecraft.getSoundManager()
        .stop(RegistryNameUtil.sound(sound), net.minecraft.sounds.SoundSource.PLAYERS));
    if (this.reloadAnimation != null) {
      this.reloadAnimation.remove();
      this.reloadAnimation = null;
    }
  }

  public float getPartialTick() {
    return ClientFrameTimeUtil.getFrameTime(this.minecraft);
  }

  protected abstract Optional<SoundEvent> getSecondaryActionSound();

  protected abstract long getSecondaryActionSoundRepeatDelayMs();

  public void handleTick(LivingExtension<?, ?> living) {
    if (living.entity() instanceof LocalPlayer
        && LIVING_HIT_VALIDATION_BUFFER.size() > 0
        && hitValidationTicks++ >= AbstractGun.HIT_VALIDATION_DELAY_TICKS) {
      hitValidationTicks = 0;
      var hits = new HashMap<Integer, java.util.Collection<PendingHit>>();
      LIVING_HIT_VALIDATION_BUFFER.asMap().forEach((entityId, pendingHits) ->
          hits.put(entityId, new ObjectArrayList<>(pendingHits)));
      
      NetworkChannel.PLAY.sendToServer(new ValidatePendingHitMessage(hits));
      LIVING_HIT_VALIDATION_BUFFER.clear();
    }

    this.getSecondaryActionSound().ifPresent(sound -> {
      long delta =
          Util.getMillis() - this.secondaryActionSoundStartTimeMs + 50;
      long repeatDelay = this.getSecondaryActionSoundRepeatDelayMs();
      if (this.gun.isPerformingSecondaryAction()
          && repeatDelay > 0L
          && delta >= repeatDelay) {
        this.secondaryActionSoundStartTimeMs = Util.getMillis();
        living.entity().playSound(sound, 1.0F, 1.0F);
      }
    });

    if (!this.gun.isTriggerPressed()) {
      this.lastShotCount = 0;
    }

    if (this.remainingFlashTicks > 0) {
      this.remainingFlashTicks--;
    }

    this.animationController.tick();
  }

  protected abstract float getRecoil();

  protected abstract SoundEvent getShootSound();

  protected abstract Optional<SoundEvent> getDistantShootSound();

  protected abstract Optional<SoundEvent> getSilencedShootSound();

  protected boolean canFlash(LivingExtension<?, ?> living) {
    return this.minecraft.options.getCameraType() == CameraType.FIRST_PERSON
        && this.gun.getShotCount() != this.lastShotCount && this.gun.getShotCount() > 0;
  }

  public void handleShoot(LivingExtension<?, ?> living) {
    var entity = living.entity();
    var gun = living.mainHandGun().orElse(null);

    if (this.canFlash(living)) {
      this.remainingFlashTicks = MUZZLE_FLASH_DURATION_TICKS;
    }

    this.lastShotCount = this.gun.getShotCount();

    if (this.currentShootAnimation != null) {
      this.currentShootAnimation.remove();
    }

    this.currentShootAnimation = this.getAnimation(GunAnimationEvent.SHOOT);
    if (!gun.isPerformingSecondaryAction()) {
      this.animationController.addAnimation(this.currentShootAnimation);
    }

    if (entity == this.minecraft.getCameraEntity()) {
      float recoilAmount = 1.0F;
      // Prone
      if (living.isCrouching()) {
        recoilAmount *= (1.0F - ServerConfig.instance.proneRecoilMultiplier.get().floatValue());
      }
      // Crouch
      if (entity.isCrouching()) {
        recoilAmount *= (1.0F - ServerConfig.instance.crouchRecoilMultiplier.get().floatValue());
      }
      // Tactical Grip attached
      if (gun.getAttachments().containsValue(Attachments.TACTICAL_GRIP.get())) {
        recoilAmount *= (1.0F - ServerConfig.instance.tacticalGripRecoilMultiplier.get().floatValue());
      }
      // Bipod attached
      if (gun.getAttachments().containsValue(Attachments.BIPOD.get())) {
        recoilAmount *= (1.0F - ServerConfig.instance.bipodRecoilMultiplier.get().floatValue());
      }
      this.client.getCameraManager().randomRecoil(this.getRecoil() * recoilAmount, true);
    }

    double sqrDistance = this.minecraft.gameRenderer.getMainCamera().getPosition()
        .distanceToSqr(entity.getX(), entity.getY(), entity.getZ());

    boolean farAway = sqrDistance > 1600.0D;

    final SoundEvent defaultShootSound = this.getShootSound();

    @Nullable
    final SoundEvent shootSound;
    boolean amplifyDistantSound = this.getDistantShootSound().isPresent();
    if (this.gun.getAttachments().values().stream().anyMatch(Attachment::isSoundSuppressor)) {
      shootSound = farAway
          ? null
          : this.getSilencedShootSound().orElse(defaultShootSound);
    } else {
      shootSound = farAway
          ? this.getDistantShootSound().orElse(defaultShootSound)
          : defaultShootSound;
    }

    if (!entity.isSilent() && shootSound != null) {
      // Sounds have to be played on the main thread (unfortunately)
      this.minecraft.execute(() -> entity.level().playLocalSound(
          entity.getX(), entity.getY(), entity.getZ(), shootSound,
          entity.getSoundSource(), farAway && amplifyDistantSound ? 8.0F : 1.0F, 1.0F, true));
    }
  }


  public void handleHitEntityPre(LivingExtension<?, ?> living, Entity hitEntity,
      Vec3 hitPos, long randomSeed) {
    if (living.entity() instanceof LocalPlayer) {
      if (!(hitEntity instanceof LivingEntity hitLivingEntity)) {
        return;
      }
      var hitLiving = LivingExtension.get(hitLivingEntity);
      if (hitLiving != null) {
        LIVING_HIT_VALIDATION_BUFFER.put(hitEntity.getId(),
            new PendingHit(
                (byte) (AbstractGun.HIT_VALIDATION_DELAY_TICKS - hitValidationTicks),
                living.makeSnapshot(ClientFrameTimeUtil.getFrameTime(this.minecraft)),
                hitLiving.makeSnapshot(ClientFrameTimeUtil.getFrameTime(this.minecraft)), randomSeed,
                this.gun.getShotCount()));
      }
    }
  }

  public void handleHitEntityPost(LivingExtension<?, ?> living, Entity hitEntity,
      Vec3 hitPos, boolean playSound, boolean headshot) {
    if (!(hitEntity instanceof LivingEntity)) {
      return;
    }

    final Level level = hitEntity.level();

    if (headshot) {
      final int particleCount = 12;
      for (int i = 0; i < particleCount; ++i) {
        level.addParticle(
            new BlockParticleOption(ParticleTypes.BLOCK, Blocks.BONE_BLOCK.defaultBlockState()),
            hitPos.x(), hitPos.y(), hitPos.z(), 0.0D, 0.0D, 0.0D);
      }
    }

    level.playSound(
        living.entity() instanceof Player ? (Player) living.entity() : null,
        hitEntity.blockPosition(), ModSoundEvents.BULLET_IMPACT_FLESH.get(), SoundSource.PLAYERS,
        1.0F, 1.0F);

    // If local player
    if (hitEntity == this.minecraft.getCameraEntity()) {
      this.client.getCameraManager().randomRecoil(1.5F, false);
    }

    final int particleCount = 12;
    for (int i = 0; i < particleCount; ++i) {
      level.addParticle(
          new BlockParticleOption(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.defaultBlockState()),
          hitPos.x(), hitPos.y(), hitPos.z(), 0.0D, 0.0D, 0.0D);
    }
  }

  public void handleHitBlock(LivingExtension<?, ?> living,
      BlockHitResult result, BlockState blockState, boolean playSound) {
    Entity entity = living.entity();
    Level level = entity.level();
    Vec3 location = result.getLocation();

    if (playSound) {
      // Gets the hit sound to be played
      SoundEvent hitSound = ModSoundEvents.BULLET_IMPACT_DIRT.get();
      SoundType soundType = blockState.getSoundType();
      if (soundType == SoundType.WOOD) {
        hitSound = ModSoundEvents.BULLET_IMPACT_WOOD.get();
      } else if (soundType == SoundType.STONE) {
        hitSound = ModSoundEvents.BULLET_IMPACT_STONE.get();
      } else if (soundType == SoundType.METAL) {
        hitSound = Math.random() > 0.5D ? ModSoundEvents.BULLET_IMPACT_METAL.get()
            : ModSoundEvents.BULLET_IMPACT_METAL2.get();
      } else if (soundType == SoundType.GLASS) {
        hitSound = ModSoundEvents.BULLET_IMPACT_GLASS.get();
      }

      level.playSound(entity instanceof Player ? (Player) entity : null,
          result.getBlockPos(), hitSound, SoundSource.BLOCKS, 1.0F, 1.0F);
    }

    final int particleCount = 12;
    for (int i = 0; i < particleCount; ++i) {
      level.addParticle(new BlockParticleOption(ParticleTypes.BLOCK, blockState), location.x(),
          location.y(), location.z(), 0.0D, 0.0D, 0.0D);
    }
  }

  public void handleToggleSecondaryAction(LivingExtension<?, ?> living) {
    this.getSecondaryActionSound().ifPresent(sound -> {
      if (this.gun.isPerformingSecondaryAction()) {
        this.secondaryActionSoundStartTimeMs = Util.getMillis();
        living.entity().playSound(sound, 1.0F, 1.0F);
      } else {
        this.minecraft.getSoundManager().stop(RegistryNameUtil.sound(sound), SoundSource.PLAYERS);
      }
    });
  }

  @Override
  public boolean isFlashing() {
    return this.remainingFlashTicks > 0;
  }

  @Override
  public AnimationController getAnimationController() {
    return this.animationController;
  }
}
