/*
 * Crafting Dead
 * Copyright (C) 2022  NexusNode LTD
 *
 * This Non-Commercial Software License Agreement (the "Agreement") is made between
 * you (the "Licensee") and NEXUSNODE (BRAD HUNTER). (the "Licensor").
 * By installing or otherwise using Crafting Dead (the "Software"), you agree to be
 * bound by the terms and conditions of this Agreement as may be revised from time
 * to time at Licensor's sole discretion.
 *
 * If you do not agree to the terms and conditions of this Agreement do not download,
 * copy, reproduce or otherwise use any of the source code available online at any time.
 *
 * https://github.com/nexusnode/crafting-dead/blob/1.18.x/LICENSE.txt
 *
 * https://craftingdead.net/terms.php
 */

package com.craftingdead.core.world.item;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.TooltipContext;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.NotNull;

public class ModShovelItem extends ShovelItem {

  private final float blockBreakSpeed;
  private final float attackDamage;

  public ModShovelItem(Tier tier, float blockBreakSpeed, float attackDamage, float attackSpeed,
      Properties properties) {
    super(tier, properties.attributes(ShovelItem.createAttributes(tier, attackDamage, attackSpeed)));
    this.blockBreakSpeed = blockBreakSpeed;
    this.attackDamage = attackDamage;
  }

  @Override
  public boolean hurtEnemy(ItemStack itemStack, LivingEntity targetEntity,
      LivingEntity attackerEntity) {
    itemStack.hurtAndBreak(1, attackerEntity, EquipmentSlot.MAINHAND);
    return true;
  }

  @Override
  public float getDestroySpeed(ItemStack itemStack, BlockState state) {
    return this.blockBreakSpeed;
  }

  @Override
  public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip,
      @NotNull TooltipFlag flag) {
    tooltip.add(Component.translatable("item.craftingdead.damage").append(" ").append(
            Component.translatable(String.valueOf(this.attackDamage))
                .withStyle(style -> style.withColor(ChatFormatting.RED)))
        .withStyle(style -> style.withColor(ChatFormatting.GRAY)));

    tooltip.add(Component.translatable("item.craftingdead.durability").append(" ").append(
            Component.translatable(String.valueOf(stack.getMaxDamage() - stack.getDamageValue()))
                .withStyle(style -> style.withColor(ChatFormatting.RED)))
        .withStyle(style -> style.withColor(ChatFormatting.GRAY)));
  }
}
