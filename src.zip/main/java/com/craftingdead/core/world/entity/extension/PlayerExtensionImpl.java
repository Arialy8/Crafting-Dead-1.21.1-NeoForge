/*
 * Crafting Dead
 * Copyright (C) 2022  NexusNode LTD
 *
 * This Non-Commercial Software License Agreement (the "Agreement") is made between
 * you (the "Licensee") and NEXUSNODE (BRAD HUNTER). (the "Licensor").
 * By installing or otherwise using Crafting Dead (the "Software"), you agree to be
 * bound by the terms and conditions of this Agreement as may be revised from time
 * to time at Licensor's sole discretion.
 *
 * If you do not agree to the terms and conditions of this Agreement do not download,
 * copy, reproduce or otherwise use any of the source code available online at any time.
 *
 * https://github.com/nexusnode/crafting-dead/blob/1.18.x/LICENSE.txt
 *
 * https://craftingdead.net/terms.php
 */

package com.craftingdead.core.world.entity.extension;

import net.minecraft.network.chat.Component;
import com.craftingdead.core.event.OpenCraftingMenuEvent;
import com.craftingdead.core.event.OpenEquipmentMenuEvent;
import com.craftingdead.core.network.NetworkChannel;
import com.craftingdead.core.network.SynchedData;
import com.craftingdead.core.network.message.play.EnableCombatModeMessage;
import com.craftingdead.core.world.action.Action;
import com.craftingdead.core.world.inventory.CraftingMenu;
import com.craftingdead.core.world.inventory.EquipmentMenu;
import com.craftingdead.core.world.item.equipment.Equipment;
import java.util.Collection;
import java.util.function.Consumer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MenuConstructor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.util.TriState;
import org.apache.commons.lang3.mutable.MutableInt;

final class PlayerExtensionImpl<E extends Player>
    extends BaseLivingExtension<E, PlayerHandler> implements PlayerExtension<E> {

  private final SynchedData data = new SynchedData();

  private static final EntityDataAccessor<Boolean> COMBAT_MODE_ENABLED =
      new EntityDataAccessor<>(0x00, EntityDataSerializers.BOOLEAN);

  private static final EntityDataAccessor<ItemStack> HANDCUFFS =
      new EntityDataAccessor<>(0x01, EntityDataSerializers.ITEM_STACK);

  private static final EntityDataAccessor<Boolean> HOLDING_RIGHT_CLICK =
      new EntityDataAccessor<>(0x02, EntityDataSerializers.BOOLEAN);

  private static final EntityDataAccessor<Integer> RIGHT_CLICK_TICKS =
      new EntityDataAccessor<>(0x03, EntityDataSerializers.INT);

  private boolean cachedCombatModeEnabled;

  PlayerExtensionImpl(E entity) {
    super(entity);
    this.data.register(COMBAT_MODE_ENABLED, false);
    this.data.register(HANDCUFFS, ItemStack.EMPTY);
    this.data.register(HOLDING_RIGHT_CLICK, false);
    this.data.register(RIGHT_CLICK_TICKS, 0);
  }

  @Override
  public void tick() {
    this.cachedCombatModeEnabled = false;
    super.tick();
  }

  @Override
  protected void tickHandler(LivingHandlerType<? extends PlayerHandler> type,
      PlayerHandler extension) {
    super.tickHandler(type, extension);
    if (extension.isCombatModeEnabled()) {
      this.cachedCombatModeEnabled = true;
    }
  }

  @Override
  public boolean performAction(Action action, boolean force, boolean sendUpdate) {
    return !this.isHandcuffed() && super.performAction(action, force, sendUpdate);
  }

  @Override
  public void playerTick() {
    if (this.isCrouching()) {
      this.entity().setPose(Pose.SWIMMING);
    }
    for (PlayerHandler handler : this.handlers.values()) {
      handler.playerTick();
    }
  }

  @Override
  public boolean isMovementBlocked() {
    return !this.entity().isSpectator() && super.isMovementBlocked();
  }

  @Override
  public boolean handleAttack(Entity target) {
    if (this.handlers.values().stream().anyMatch(e -> e.handleAttack(target))) {
      return true;
    }
    return this.isHandcuffed();
  }

  @Override
  public boolean handleInteract(InteractionHand hand, Entity target) {
    if (this.handlers.values().stream().anyMatch(e -> e.handleInteract(hand, target))) {
      return true;
    }
    return this.isHandcuffed();
  }

  @Override
  public boolean handleLeftClickBlock(BlockPos pos, Direction face,
      Consumer<TriState> attackResult, Consumer<TriState> mineResult) {
    if (this.handlers.values().stream()
        .anyMatch(e -> e.handleLeftClickBlock(pos, face, attackResult, mineResult))) {
      return true;
    }

    if (this.isHandcuffed()) {
      if (this.level().isClientSide()) {
        mineResult.accept(TriState.FALSE);
      }
      return true;
    }

    return false;
  }

  @Override
  public boolean handleRightClickBlock(InteractionHand hand, BlockPos pos, Direction face) {
    if (this.handlers.values().stream().anyMatch(e -> e.handleRightClickBlock(hand, pos, face))) {
      return true;
    }
    return this.isHandcuffed();
  }

  @Override
  public boolean handleRightClickItem(InteractionHand hand) {
    if (this.handlers.values().stream().anyMatch(e -> e.handleRightClickItem(hand))) {
      return true;
    }
    return this.isHandcuffed();
  }

  public boolean handleBlockBreak(BlockPos pos, BlockState block, MutableInt xp) {
    return this.handlers.values().stream().anyMatch(e -> e.handleBlockBreak(pos, block, xp));
  }

  @Override
  public boolean isHoldingRightClick() {
    return this.data.get(HOLDING_RIGHT_CLICK);
  }

  @Override
  public int getRightClickTicks() {
    return this.data.get(RIGHT_CLICK_TICKS);
  }

  @Override
  public void setHoldingRightClick(boolean value) {
    this.data.set(HOLDING_RIGHT_CLICK, value);
  }

  @Override
  public void setRightClickTicks(int ticks) {
    this.data.set(RIGHT_CLICK_TICKS, ticks);
  }

  @Override
  public boolean isCombatModeEnabled() {
    return !this.entity().isSpectator()
        && (this.cachedCombatModeEnabled || this.data.get(COMBAT_MODE_ENABLED));
  }

  @Override
  public void setCombatModeEnabled(boolean combatModeEnabled) {
    if (this.level().isClientSide() && combatModeEnabled != this.isCombatModeEnabled()) {
      NetworkChannel.PLAY.sendToServer(
          new EnableCombatModeMessage(combatModeEnabled));
    } else {
      this.data.set(COMBAT_MODE_ENABLED, combatModeEnabled);
    }
  }

  @Override
  public void openEquipmentMenu() {
    var equipEvent = new OpenEquipmentMenuEvent(this);
    NeoForge.EVENT_BUS.post(equipEvent);
    if (equipEvent.isCanceled()) {
      return;
    }
    this.entity().openMenu(new SimpleMenuProvider(
        (windowId, inventory, player) -> new EquipmentMenu(windowId, this),
        Component.translatable("container.equipment")));
  }

  @Override
  public void openCraftingMenu() {
    var craftEvent = new OpenCraftingMenuEvent(this);
    NeoForge.EVENT_BUS.post(craftEvent);
    if (craftEvent.isCanceled()) {
      return;
    }
    this.entity().openMenu(new SimpleMenuProvider(
        (windowId, inventory, player) -> new CraftingMenu(windowId, this),
        Component.translatable("container.crafting")));
  }

  @Override
  public void openMenu(Equipment.Slot slot) {
    var itemStack = this.getItemInSlot(slot);
    Equipment.get(itemStack)
        .filter(MenuConstructor.class::isInstance)
        .map(MenuConstructor.class::cast)
        .ifPresent(constructor -> this.entity().openMenu(
            new SimpleMenuProvider(constructor, itemStack.getHoverName())));
  }

  @Override
  public boolean handleDeathLoot(DamageSource cause, Collection<ItemEntity> drops,
      int lootingLevel) {
    if (super.handleDeathLoot(cause, drops, lootingLevel)) {
      return true;
    }

    var handcuffs = this.getHandcuffs();
    if (!handcuffs.isEmpty()) {
      var itemEntity = new ItemEntity(this.level(), this.entity().getX(),
          this.entity().getY(), this.entity().getZ(), handcuffs);
      itemEntity.setDefaultPickUpDelay();
      drops.add(itemEntity);
    }

    return false;
  }

  @Override
  protected boolean keepInventory() {
    return this.level().getGameRules().getBoolean(GameRules.RULE_KEEPINVENTORY);
  }

  @Override
  public void copyFrom(PlayerExtension<ServerPlayer> that, boolean wasDeath) {
    // Copies the inventory. Doesn't actually matter if it was death or not.
    // Death drops from 'that' should be cleared on death drops to prevent item duplication.
    for (var slot : Equipment.Slot.values()) {
      this.setItemInSlot(slot, that.getItemInSlot(slot));
    }

    for (var extension : this.handlers.values()) {
      extension.copyFrom(that, wasDeath);
    }

    this.setCombatModeEnabled(that.isCombatModeEnabled());

    if (!wasDeath) {
      this.setHandcuffs(that.getHandcuffs());
    } else {
      // Clear trauma effects on death (they shouldn't persist after respawn)
      this.entity().removeEffect(MobEffects.BLINDNESS);
      this.entity().removeEffect(MobEffects.CONFUSION);
      this.entity().removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
    }
  }

  @Override
  public CompoundTag serializeNBT() {
    var tag = super.serializeNBT();
    tag.put("handcuffs", com.craftingdead.core.util.ItemStackNbtUtil.save(this.getHandcuffs()));
    return tag;
  }

  @Override
  public void deserializeNBT(CompoundTag tag) {
    super.deserializeNBT(tag);
    if (tag.contains("handcuffs", Tag.TAG_COMPOUND)) {
      this.setHandcuffs(com.craftingdead.core.util.ItemStackNbtUtil.parseOptional(tag.getCompound("handcuffs")));
    }
  }

  @Override
  public void encode(FriendlyByteBuf out, boolean writeAll) {
    super.encode(out, writeAll);
    SynchedData.pack(
        writeAll ? this.data.getAll() : this.data.packDirty(), out);

  }

  @Override
  public void decode(FriendlyByteBuf in) {
    super.decode(in);
    this.data.assignValues(SynchedData.unpack(in));
  }

  @Override
  public boolean requiresSync() {
    return super.requiresSync() || this.data.isDirty();
  }

  @Override
  public ItemStack getHandcuffs() {
    return this.data.get(HANDCUFFS);
  }

  @Override
  public void setHandcuffs(ItemStack itemStack) {
    this.data.set(HANDCUFFS, itemStack);
  }
}
