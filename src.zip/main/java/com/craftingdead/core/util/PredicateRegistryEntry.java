/*
 * Crafting Dead
 * Copyright (C) 2022  NexusNode LTD
 *
 * This Non-Commercial Software License Agreement (the "Agreement") is made between
 * you (the "Licensee") and NEXUSNODE (BRAD HUNTER). (the "Licensor").
 * By installing or otherwise using Crafting Dead (the "Software"), you agree to be
 * bound by the terms and conditions of this Agreement as may be revised from time
 * to time at Licensor's sole discretion.
 *
 * If you do not agree to the terms and conditions of this Agreement do not download,
 * copy, reproduce or otherwise use any of the source code available online at any time.
 *
 * https://github.com/nexusnode/crafting-dead/blob/1.18.x/LICENSE.txt
 *
 * https://craftingdead.net/terms.php
 */

package com.craftingdead.core.util;

import java.util.function.Predicate;

public class PredicateRegistryEntry<T> implements Predicate<T> {

  private final Predicate<T> predicate;

  public PredicateRegistryEntry(Predicate<T> predicate) {
    this.predicate = predicate;
  }

  @Override
  public boolean test(T t) {
    return predicate.test(t);
  }

  public static <T> PredicateRegistryEntry<T> of(Predicate<T> predicate) {
    return new PredicateRegistryEntry<>(predicate);
  }

  // Work around type erasure
  @SuppressWarnings("unchecked")
  public static <T> Class<PredicateRegistryEntry<T>> asClass() {
    return (Class<PredicateRegistryEntry<T>>) (Class<?>) PredicateRegistryEntry.class;
  }
}
