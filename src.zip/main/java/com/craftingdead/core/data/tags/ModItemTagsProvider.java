/*
 * Crafting Dead
 * Copyright (C) 2022  NexusNode LTD
 *
 * This Non-Commercial Software License Agreement (the "Agreement") is made between
 * you (the "Licensee") and NEXUSNODE (BRAD HUNTER). (the "Licensor").
 * By installing or otherwise using Crafting Dead (the "Software"), you agree to be
 * bound by the terms and conditions of this Agreement as may be revised from time
 * to time at Licensor's sole discretion.
 *
 * If you do not agree to the terms and conditions of this Agreement do not download,
 * copy, reproduce or otherwise use any of the source code available online at any time.
 *
 * https://github.com/nexusnode/crafting-dead/blob/1.18.x/LICENSE.txt
 *
 * https://craftingdead.net/terms.php
 */

package com.craftingdead.core.data.tags;

import com.craftingdead.core.CraftingDead;
import com.craftingdead.core.tags.ModItemTags;
import com.craftingdead.core.world.item.ModItems;
import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.neoforged.neoforge.common.data.BlockTagsProvider;
import net.minecraft.data.tags.ItemTagsProvider;
import net.minecraft.data.tags.TagsProvider.TagLookup;
import net.neoforged.neoforge.common.data.ExistingFileHelper;

public class ModItemTagsProvider extends ItemTagsProvider {

  public ModItemTagsProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> lookupProvider,
      CompletableFuture<TagLookup<net.minecraft.world.level.block.Block>> blockTags,
      ExistingFileHelper existingFileHelper) {
    super(output, lookupProvider, blockTags, CraftingDead.ID, existingFileHelper);
  }

  @Override
  public void addTags(HolderLookup.Provider provider) {
    this.tag(ModItemTags.MAGAZINES)
        .add(ModItems.STANAG_BOX_MAGAZINE.get())
        .add(ModItems.STANAG_DRUM_MAGAZINE.get())
        .add(ModItems.STANAG_30_ROUND_MAGAZINE.get())
        .add(ModItems.STANAG_20_ROUND_MAGAZINE.get())
        .add(ModItems.MPT55_MAGAZINE.get())
        .add(ModItems.AK47_30_ROUND_MAGAZINE.get())
        .add(ModItems.FNFAL_MAGAZINE.get())
        .add(ModItems.ACR_MAGAZINE.get())
        .add(ModItems.G36C_MAGAZINE.get())
        .add(ModItems.HK417_MAGAZINE.get())
        .add(ModItems.M1911_MAGAZINE.get())
        .add(ModItems.G18_MAGAZINE.get())
        .add(ModItems.M9_MAGAZINE.get())
        .add(ModItems.DESERT_EAGLE_MAGAZINE.get())
        .add(ModItems.P250_MAGAZINE.get())
        .add(ModItems.MAGNUM_AMMUNITION.get())
        .add(ModItems.FN57_MAGAZINE.get())
        .add(ModItems.P90_MAGAZINE.get())
        .add(ModItems.VECTOR_MAGAZINE.get())
        .add(ModItems.MP5A5_21_ROUND_MAGAZINE.get())
        .add(ModItems.MP5A5_35_ROUND_MAGAZINE.get())
        .add(ModItems.MAC10_EXTENDED_MAGAZINE.get())
        .add(ModItems.MAC10_MAGAZINE.get())
        .add(ModItems.SPORTER22_MAGAZINE.get())
        .add(ModItems.M107_MAGAZINE.get())
        .add(ModItems.AS50_MAGAZINE.get())
        .add(ModItems.M1GARAND_AMMUNITION.get())
        .add(ModItems.AWP_MAGAZINE.get())
        .add(ModItems.TRENCH_GUN_SHELLS.get())
        .add(ModItems.MOSSBERG_SHELLS.get())
        .add(ModItems.DMR_MAGAZINE.get())
        .add(ModItems.TASER_CARTRIDGE.get())
        .add(ModItems.ROCKET.get())
        .add(ModItems.M240B_MAGAZINE.get())
        .add(ModItems.RPK_DRUM_MAGAZINE.get())
        .add(ModItems.RPK_MAGAZINE.get())
        .add(ModItems.MINIGUN_MAGAZINE.get())
        .add(ModItems.MK48MOD_MAGAZINE.get());

    this.tag(ModItemTags.SYRINGES).add(ModItems.ADRENALINE_SYRINGE.get(),
        ModItems.SYRINGE.get(), ModItems.BLOOD_SYRINGE.get());
    this.tag(ModItemTags.CLOTHING).add(ModItems.ARMY_CLOTHING.get(),
        ModItems.ARMY_DESERT_CLOTHING.get(), ModItems.ARMY_MEDIC_CLOTHING.get(),
        ModItems.BLUE_DUSK_CLOTHING.get(), ModItems.BUILDER_CLOTHING.get(),
        ModItems.BUSINESS_CLOTHING.get(), ModItems.CAMO_CLOTHING.get(),
        ModItems.CASUAL_GREEN_CLOTHING.get(), ModItems.CLONE_CLOTHING.get(),
        ModItems.COMBAT_BDU_CLOTHING.get(), ModItems.CONTRACTOR_CLOTHING.get(),
        ModItems.COOKIE_CLOTHING.get(), ModItems.DDPAT_CLOTHING.get(),
        ModItems.DEADPOOL_CLOTHING.get(), ModItems.DOCTOR_CLOTHING.get(),
        ModItems.FIREMAN_CLOTHING.get(), ModItems.FULL_GHILLIE_CLOTHING.get(),
        ModItems.GREEN_DUSK_CLOTHING.get(), ModItems.HAZMAT_CLOTHING.get(),
        ModItems.JUGGERNAUT_CLOTHING.get(), ModItems.MIL_HAZMAT_CLOTHING.get(),
        ModItems.NINJA_CLOTHING.get(), ModItems.ORANGE_DUSK_CLOTHING.get(),
        ModItems.PILOT_CLOTHING.get(), ModItems.POLICE_CLOTHING.get(),
        ModItems.PRESIDENT_CLOTHING.get(), ModItems.PURPLE_DUSK_CLOTHING.get(),
        ModItems.RED_DUSK_CLOTHING.get(), ModItems.SAS_CLOTHING.get(),
        ModItems.SCUBA_CLOTHING.get(), ModItems.SEC_GUARD_CLOTHING.get(),
        ModItems.SHERIFF_CLOTHING.get(), ModItems.SMART_CLOTHING.get(),
        ModItems.SPACE_SUIT_CLOTHING.get(), ModItems.SPETSNAZ_CLOTHING.get(),
        ModItems.SWAT_CLOTHING.get(), ModItems.TAC_GHILLIE_CLOTHING.get(),
        ModItems.WHITE_DUSK_CLOTHING.get(), ModItems.WINTER_ARMY_CLOTHING.get(),
        ModItems.YELLOW_DUSK_CLOTHING.get());
    this.tag(ModItemTags.BACKPACK).add(ModItems.SMALL_RED_BACKPACK.get(),
        ModItems.SMALL_ORANGE_BACKPACK.get(), ModItems.SMALL_YELLOW_BACKPACK.get(),
        ModItems.SMALL_GREEN_BACKPACK.get(), ModItems.SMALL_BLUE_BACKPACK.get(),
        ModItems.SMALL_PURPLE_BACKPACK.get(), ModItems.MEDIUM_RED_BACKPACK.get(),
        ModItems.MEDIUM_ORANGE_BACKPACK.get(), ModItems.MEDIUM_YELLOW_BACKPACK.get(),
        ModItems.MEDIUM_GREEN_BACKPACK.get(), ModItems.MEDIUM_BLUE_BACKPACK.get(),
        ModItems.MEDIUM_PURPLE_BACKPACK.get(), ModItems.MEDIUM_GREY_BACKPACK.get(),
        ModItems.MEDIUM_BLACK_BACKPACK.get(), ModItems.MEDIUM_GHILLIE_BACKPACK.get(),
        ModItems.MEDIUM_WHITE_BACKPACK.get(), ModItems.LARGE_GREY_BACKPACK.get(),
        ModItems.LARGE_GREEN_BACKPACK.get(), ModItems.LARGE_TAN_BACKPACK.get(),
        ModItems.LARGE_BLACK_BACKPACK.get(), ModItems.LARGE_GHILLIE_BACKPACK.get());
    this.tag(ModItemTags.VEST).add(ModItems.BLACK_TACTICAL_VEST.get(),
        ModItems.GHILLIE_TACTICAL_VEST.get(), ModItems.GREEN_TACTICAL_VEST.get(),
        ModItems.GREY_TACTICAL_VEST.get(), ModItems.RIOT_VEST.get(),
        ModItems.TAN_TACTICAL_VEST.get());
    this.tag(ModItemTags.MELEES).add(ModItems.BAT.get(), ModItems.BO_STAFF.get(),
        ModItems.BOLT_CUTTERS.get(), ModItems.BOWIE_KNIFE.get(), ModItems.BROADSWORD.get(),
        ModItems.BROKEN_BOTTLE.get(), ModItems.CHAINSAW.get(), ModItems.CLEAVER.get(),
        ModItems.COMBAT_KNIFE.get(), ModItems.CROWBAR.get(), ModItems.FIRE_AXE.get(),
        ModItems.FRYING_PAN.get(), ModItems.GOLF_CLUB.get(), ModItems.HATCHET.get(),
        ModItems.KATANA.get(), ModItems.MACHETE.get(), ModItems.NAIL_BAT.get(),
        ModItems.NIGHT_STICK.get(), ModItems.PICKAXE.get(), ModItems.PIPE.get(),
        ModItems.RUSTY_PIPE.get(), ModItems.SCYTHE.get(), ModItems.SHOVEL.get(),
        ModItems.SLEDGEHAMMER.get(), ModItems.STEEL_BAT.get(), ModItems.WEAPONIZED_SCYTHE.get(),
        ModItems.WRENCH.get());
    this.tag(ModItemTags.HATS).add(ModItems.BEANIE_HAT.get(),
        ModItems.BLACK_BALLISTIC_HAT.get(), ModItems.BLUE_HARD_HAT.get(), ModItems.BUNNY_HAT.get(),
        ModItems.CLONE_HAT.get(), ModItems.FIREMAN_CHIEF_HAT.get(), ModItems.FIREMAN_HAT.get(),
        ModItems.GHILLIE_HAT.get(), ModItems.GREEN_HARD_HAT.get(), ModItems.HAZMAT_HAT.get(),
        ModItems.KNIGHT_HAT.get(), ModItems.MILITARY_HAZMAT_HAT.get(), ModItems.NINJA_HAT.get(),
        ModItems.NV_GOGGLES_HAT.get(), ModItems.ORANGE_HARD_HAT.get(), ModItems.RIOT_HAT.get(),
        ModItems.SANTA_HAT.get(), ModItems.TOP_HAT.get(), ModItems.TRAPPER_HAT.get(),
        ModItems.USHANKA_HAT.get(), ModItems.YELLOW_HARD_HAT.get(), ModItems.ARMY_HELMET.get(),
        ModItems.CREEPER_MASK.get(), ModItems.COW_MASK.get(), ModItems.COOKIE_MASK.get(),
        ModItems.COMBAT_BDU_HELMET.get(), ModItems.CAMO_HELMET.get(), ModItems.DOCTOR_MASK.get(),
        ModItems.DEADPOOL_MASK.get(), ModItems.GAS_MASK.get(), ModItems.GREEN_ARMY_HELMET.get(),
        ModItems.GREEN_BALLISTIC_HELMET.get(), ModItems.GREY_ARMY_HELMET.get(), ModItems.HACKER_MASK.get(),
        ModItems.JUGGERNAUT_HELMET.get(), ModItems.PAYDAY_MASK.get(), ModItems.PILOT_HELMET.get(),
        ModItems.PAYDAY2_MASK.get(), ModItems.PUMPKIN_MASK.get(), ModItems.RADAR_CAP.get(),
        ModItems.SCUBA_MASK.get(), ModItems.SHEEP_MASK.get(), ModItems.SKI_MASK.get(),
        ModItems.ZOMBIE_MASK.get(), ModItems.WINTER_MILITARY_HELMET.get(), ModItems.SPETSNAZ_HELMET.get());
  }

  @Override
  public String getName() {
    return "Crafting Dead Item Tags";
  }
}
